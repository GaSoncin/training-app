import React from "react";
import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import LoginPage from "./pages/LoginPage/LoginPage";
import TrainingPage from "./pages/TrainingPage/TrainingPage";
import "./App.css";
import TrainingJourney from "./pages/TrainingJourney/TrainingJourney";

const App: React.FC = () => {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<LoginPage />} />
        <Route path="/trainings" element={<TrainingPage />} />
        <Route path="/trainings-journey" element={<TrainingJourney />} />
      </Routes>
    </Router>
  );
};

export default App;