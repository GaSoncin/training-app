import React from "react";
import { useNavigate } from "react-router-dom"; // Importando useNavigate para navegação
import TrainingList from "../../components/TrainingList/TrainingList";
import "./TrainingPage.css";
import profileImage from "../../assets/user.png";

const TrainingPage: React.FC = () => {
  const navigate = useNavigate();

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    navigate("/trainings-journey");
  };

  return (
    <div className="training-page">
      <div className="header">
        <div className="menu">
          <span className="menu-icon">≡</span>
          <span className="menu-text">menu</span>
        </div>
      </div>
      <div className="profile-section">
        <h1 className="username">
          NOME
          <br />
          USUÁRIO
        </h1>
        <img src={profileImage} alt="User Profile" className="profile-image" />
        <div>
          <h2 className="title-training">TESTE</h2>
        </div>
      </div>
      <div className="training-list-container">
        <TrainingList />
      </div>
      <form className="b2-container" onSubmit={handleSubmit}>
        <button className="b2" type="submit">Continuar para treinamentos <br />(TESTE)</button>
      </form>
    </div>  
  );
};

export default TrainingPage;