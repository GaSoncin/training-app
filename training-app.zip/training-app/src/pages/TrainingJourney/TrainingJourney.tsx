import React from "react";
import "./TrainingJourney.css";

const TrainingJourney: React.FC = () => {
  return (
    <div className="training-page">
      <div className="header">
        <div className="menu">
          <span className="menu-icon">≡</span>
          <span className="menu-text">menu</span>
        </div>
      </div>
      <div className="profile-section">
        <h2 className="title-training"></h2>
      </div>
    </div>
  );
};

export default TrainingJourney;